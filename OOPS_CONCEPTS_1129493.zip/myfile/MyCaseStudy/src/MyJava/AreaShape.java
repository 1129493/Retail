package MyJava;


//abstarct and interafce
abstract class AreaShape 
{
  abstract void findArea(double a);
  public void findArea(int x,int y)
  {
	  System.out.println("rect area="+x*y);
  }
}

interface AreaShape3
{
	public void findArea(int s);
	
}
class AreaShape1 extends AreaShape implements AreaShape3
{
   void findArea(double a) 
	{
		double pi=3.14;
		System.out.println("circle area="+pi*a);
		
	}


   public void findArea(int s) 
   {
	   int p=s*s;
	   System.out.println("square area="+p);
	
	
}
	
}
