package MyJava;

public class TestMain {

	
	public static void main(String[] args) 
	{
		AreaShape1 as=new AreaShape1();
		as.findArea(4.0);
		as.findArea(4, 5);
		as.findArea(6);
		
	}

}
