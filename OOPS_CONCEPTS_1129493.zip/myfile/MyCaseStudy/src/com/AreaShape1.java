package com;

// inheritance and overriding
public class AreaShape1 
{
   public void findArea(int x)
   {
	   int a=x*x;
	   System.out.println("base class square area"+a);
   }
   public void findArea(int k,int l)
   {
	   int b=k*l;
	   System.out.println("base class rect"+b);
   }
}

class AreaShape2 extends AreaShape1
{
	public void findArea(int p)
	{
		int d=p*p;
		System.out.println("child class square"+d);
	}
	public void findArea(double k)
	{
		double pi=3.14;
		double x=pi*k;
		System.out.println("child circle"+x);
	}

}
