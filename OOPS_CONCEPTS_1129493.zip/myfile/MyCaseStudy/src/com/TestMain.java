package com;

class TestMain
{
	public static void main(String args[])
	{
		AreaShape2 as2=new AreaShape2();
		as2.findArea(4);
		as2.findArea(4.0);
		as2.findArea(4, 5);

	}
}	


