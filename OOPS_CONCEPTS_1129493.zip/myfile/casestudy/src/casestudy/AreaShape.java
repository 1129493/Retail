package casestudy;

//constructors and overloading
public class AreaShape 
{
	static double pi=3.14;
	//constructors
	AreaShape()
	{
		System.out.println("default constructor");
	}
	AreaShape(double x)
	{
		System.out.println("circle radius"+pi*x);
	}
	AreaShape(int a,int b)
	{
		System.out.println("rect area="+a*b);
	}
	AreaShape(int s)
	{
		System.out.println("square area="+s*s);
	}
	
	//overloading
	public void findArea(double s1)
	{
		double m=pi*s1;
		System.out.println("circle radius"+m);
	}
	public void findArea(int a1)
	{
		int c=a1*a1;
		System.out.println("square radius"+c);
	}
	public void findArea(int v,int b)
	{
		int d=v*b;
		System.out.println("react radius"+d);
	}
    public static void main(String args[])
    {
    	AreaShape as=new AreaShape();
    	AreaShape as1=new AreaShape(5.0);
    	AreaShape as2=new AreaShape(4);
    	AreaShape as3=new AreaShape(2,6);
    	as1.findArea(3.0);
    	as2.findArea(5);
    	as3.findArea(5, 2);
    	
    }
}
