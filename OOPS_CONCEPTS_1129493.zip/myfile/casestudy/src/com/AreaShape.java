package com;

public abstract class AreaShape 
{
	static double pi=3.14;
	AreaShape()
	{
		System.out.println("AreaShape constructor");
	}
	 public double findArea(double radius)
	{
		return pi*radius;
		
	}
	 public void findArea(int a,int b)
	 {
		 int s=a*b;
		 System.out.println("int first class="+s);
	 }
   abstract void findArea(int l);
   
}
interface AreaShape4
{
	void findArea();
}


class AreaShape1 extends AreaShape implements AreaShape4
{
	public void findArea(int x,int y)
	{
	  int k= x*y;
	  System.out.println("in second class over riding="+k);
	}
	void findArea(int l) 
	{
		int n=l*l;
		System.out.println("in second class abstract method="+n);
		
	}
	
	public void findArea() 
	{
	System.out.println("interface area method");	
		
	}
}


