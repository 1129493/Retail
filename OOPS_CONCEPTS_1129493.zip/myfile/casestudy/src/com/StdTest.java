package com;

import java.util.ArrayList;

public class StdTest {

	public static void main(String[] args) 
	{
		Student s1=new Student(11,"satish");
		Student s2=new Student(12,"gautam");
		Student s3=new Student(13,"ram");
		ArrayList<Student> alist=new ArrayList<Student>();
		alist.add(s1);
		alist.add(s2);
		alist.add(s3);
		System.out.println("the list contains\n");
		for(Student s:alist)
		{
			System.out.println("id="+s.getIdNum()+"\n name="+s.getName());
		}
			
		
		alist.remove(s2);

		System.out.println("\nafter removing");
		for(Student s:alist)
		{

			System.out.println("id="+s.getIdNum()+"\n name="+s.getName());

		}
		
	}

}
