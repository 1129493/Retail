package com;

public class TestMain {

	
	public static void main(String[] args) 
	{
		AreaShape1 as=new AreaShape1();
		double circle=as.findArea(5.0);
		System.out.println("circle area="+circle);
		as.findArea(4,5);
		as.findArea(4);
		as.findArea();
		
	}

}
