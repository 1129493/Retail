package com;

import java.util.ArrayList;
import java.util.LinkedList;

public class StdTest 
{
public static void main(String[] args) 
{
	Student s1=new Student(11,"satish");
	Student s2=new Student(12,"gautam");
	Student s3=new Student(13,"ram");
	ArrayList<Student> alist=new ArrayList<Student>();
	alist.add(s1);
	alist.add(s2);
	alist.add(s3);
	System.out.println(" @this is arraylist@");
	for(Student s:alist)
	{
		System.out.println("id="+s.getIdNum()+"\n name="+s.getName());
	}
	LinkedList<Student> llist=new LinkedList<Student>();
	
	Student s4=new Student(21,"vamsi");
	Student s5=new Student(22,"amar");
	llist.add(s4);
	llist.add(s5);
	System.out.println("this is linked list");
	for(Student k:llist)
	{
		System.out.println("id="+k.getIdNum()+"\n name="+k.getName());
	}
	
}

}
