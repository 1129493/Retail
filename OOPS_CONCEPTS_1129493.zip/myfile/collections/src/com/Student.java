
package com;

public class Student 
{
	private int idNum;
	private String name;
	public Student(int idNum, String name)
   {
		super();
		this.idNum = idNum;
		this.name = name;
	}
	public int getIdNum() {
		return idNum;
	}
	public void setIdNum(int idNum) {
		this.idNum = idNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

