package map;

import com.Student;
import java.util.*;

public class StdTest 
{
	public static void main(String[] args) 
	{
		Student s1=new Student(11,"satish");
		Student s2=new Student(15,"gautam");
		Student s3=new Student(13,"ram");
		HashMap<Integer,Student> hm=new HashMap<Integer,Student>();
		hm.put(1,s1);
		hm.put(2,s2);
		hm.put(3,s3);
		System.out.println("details");
		for(Map.Entry<Integer,Student> etr:hm.entrySet())
		{ 
			int key=etr.getKey();
			Student s=etr.getValue();
			
			System.out.println("id="+s.getIdNum()+" "+"name="+s.getName());  
		}
		LinkedHashMap<Integer,Student> lhm=new LinkedHashMap<Integer,Student>();
		Student s4=new Student(17,"sai");
		Student s5=new Student(15,"jithin");
		lhm.put(1,s4);
		lhm.put(2,s5);
		System.out.println("details");
		for(Map.Entry<Integer,Student> etr:lhm.entrySet())
		{ 
			int key=etr.getKey();
			Student s=etr.getValue();
			
			System.out.println("id="+s.getIdNum()+" "+"name="+s.getName());  
		}
	}
}