package set;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeSet;

import com.Student;

public class StdTest 
{
public static void main(String[] args) 
{
	Student s1=new Student(11,"satish");
	Student s2=new Student(12,"gautam");
	Student s3=new Student(13,"ram");
	HashSet<Student> hlist=new HashSet<Student>();
	hlist.add(s1);
	hlist.add(s2);
	hlist.add(s3);
	
	System.out.println(" @this is hashSet@");
	for(Student s:hlist)
	{
		System.out.println("id="+s.getIdNum()+"\n name="+s.getName());
	}
	LinkedHashSet<Student> lhlist=new LinkedHashSet<Student>();
	Student s4=new Student(21,"venky");
	Student s5=new Student(31,"vinay");
	Student s6=new Student(41,"vinod");
	lhlist.add(s4);
	lhlist.add(s5);
	lhlist.add(s6);
    System.out.println(" @this is Linked hashSet@");
	for(Student s:lhlist)
	{
		System.out.println("id="+s.getIdNum()+"\n name="+s.getName());
	}
	TreeSet<Student> tslist=new TreeSet<Student>();
	Student s7=new Student(101,"manu");
	Student s8=new Student(121,"priya");
	Student s9=new Student(111,"moni");
	tslist.add(s7);
	//tslist.add(s8);
	tslist.add(s9);
	System.out.println(" @this is TreeSet@");
	for(Student s:tslist)
	{
		System.out.println("id="+s.getIdNum()+"\n name="+s.getName());
	}
}
}